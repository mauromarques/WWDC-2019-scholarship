//
//  File.swift
//  Playgrounds Author Template Extension
//
//  Created by Mauro Marques on 19/03/2019.
//

import Foundation
import UIKit


func run(after seconds: Int, completion: @escaping () -> Void) {
    let deadline = DispatchTime.now() + .seconds(seconds)
    DispatchQueue.main.asyncAfter(deadline: deadline) {
        completion()
    }
    
}


func animateDangerText2 (view: UIView, dangerLabelConstraint: NSLayoutConstraint) -> Void{
    
    UIView.animate(withDuration: 1, delay: 0.1, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
        
        dangerLabelConstraint.constant = 140
        view.layoutIfNeeded()
        
    }, completion: { (true) in
        run(after: 2, completion: {
            UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
                
                dangerLabelConstraint.constant = -70
                view.layoutIfNeeded()
                
                print ("caguei mole e a bosta escorreu")
                
            })
        })
    })
    
}
