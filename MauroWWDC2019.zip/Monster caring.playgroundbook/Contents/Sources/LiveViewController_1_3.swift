//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  Provides supporting functions for setting up a live view.
//

import UIKit
import Foundation
import PlaygroundSupport


 class LiveViewController_1_3: LiveViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    
    var monsterCalled = String()
    
    var testCenterY = NSLayoutConstraint()
    var testCenterX = NSLayoutConstraint()
    var testBottomConstraint = NSLayoutConstraint()
    let testImage = UIImageView()
    
    func setuptest(){
        view.addSubview(testImage)
        view.bringSubviewToFront(testImage)
        
        testImage.backgroundColor = .clear
        testImage.loadGif(name: "monsterwait2")
        
        testImage.translatesAutoresizingMaskIntoConstraints = false
        
        testCenterY = testImage.centerYAnchor.constraint(equalTo: monsterGif.centerYAnchor, constant: 0)
        testCenterY.isActive=true
        testCenterX = testImage.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: 1000)
        testCenterX.isActive=true
        testImage.heightAnchor.constraint(equalToConstant: 350).isActive=true
        testImage.widthAnchor.constraint(equalToConstant: 350).isActive=true
    }
    
    
    func animateTest(){
        testCenterX.constant = 170
        monsterCarCenterXConstraint.constant = 170
        
        UIView.animate(withDuration: 3, delay: 0, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseOut, animations: {
            self.view.layoutIfNeeded()
        })
        { (true) in
            
            self.view.bringSubviewToFront(self.monsterGif)
                UIView.animate(withDuration: 2, delay: 0, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseIn, animations: {
                    self.monsterCarCenterXConstraint.constant = -850
                    self.view.layoutIfNeeded()
                }, completion: { (true) in
                    self.animateHeart()
                })
            
        }
        
    }
    
    
    var monsterCarCenterXConstraint = NSLayoutConstraint()
    let monsterCar = UIImageView()
    
    let heartExplosive = UIImageView()
    let flyingMonster = UIImageView()
    
    let saddyNumber = 12345
    let lonyNumber = 56789
    
    let deleteButton = UIButton()
    let startButton = UIButton()
    
    var numberAtIndex = Int()
    var numbersArray = [1,2,3,4,5,6,7,8,9]
    
    lazy var numbersCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.dataSource = self
        cv.delegate = self
        cv.isScrollEnabled = false
        return cv
    }()
    
    let cellId = "cellId"
    
    var numberVisorLabel = UILabel()
    
    let phoneView = UIView()
    var phoneViewBottomConstraint = NSLayoutConstraint()
    
    let callButton = UIButton()
    
    var dangerLabel = UILabel()
    var dangerLabelTopConstraint = NSLayoutConstraint()
    
    var guideText = UILabel()
    var guideTextTopConstraint = NSLayoutConstraint()
    
    var farBackground: UIImageView = {
        var back = UIImageView()
        back.contentMode = .scaleAspectFill
        back.backgroundColor = .clear
        back.image = UIImage(named: "farimage")
        return back
    }()
    
    var cloudsBottomConstraint = NSLayoutConstraint()
    
    var clouds: UIImageView = {
        var clo = UIImageView()
        clo.backgroundColor = .clear
        clo.image = UIImage(named: "Clouds")
        clo.contentMode = .scaleAspectFit
        return clo
    }()
    var background: UIImageView = {
        var back = UIImageView()
        back.contentMode = .scaleAspectFit
        back.backgroundColor = .white
        
        //        back.image = UIImage(named: "park")
        
        return back
    }()
    
    var monsterGif: UIImageView = {
        var gif = UIImageView()
        gif.contentMode = .scaleAspectFit
        gif.loadGif(name: "monstercurrupted")
        return gif
    }()
    
    var selectedAtIndex = UIImage()
    let selectedFoodImage: UIImageView = {
        let image = UIImageView()
        image.contentMode = .scaleAspectFit
        return image
    }()
    
    let foodListView = UIView()
    var foodListBottomConstraint: NSLayoutConstraint!
    
    
    public override func viewWillLayoutSubviews() {
        setupPhoneView()
        setupNumberVisor()
        setupNumbersCollectionView()
        setupStartButton()
        setupDeleteButton()
    }
    
    
    
    public override func viewDidAppear(_ animated: Bool) {
        
        appear(xamo: self.view)
//        setupPhoneView()
//        setupNumberVisor()
//        setupNumbersCollectionView()
        setupCallButton()

        
        self.run(after: 1) {
            self.animateDangerText2(view: self.view, dangerLabelConstraint: self.dangerLabelTopConstraint)
        }

        

    }
    
    public override func loadView() {
        let view3 = UIView()
        view3.backgroundColor = .white
        self.view = view3
        
        currentAnalysis = "Dangerous!"
        
        page = 2
        guideTextText = "Call for help"
        
        setupMonster(xama: view)
//        setupHeartExplosion()
        setupGuideText(xama: view)
        setupDangerLabel(xama: view)
        
        //        setupSelectedFoodImage()
        
            self.setupFoodList(xama: self.view)
            self.animateFoodList(xame: self.view)
        
        
        
        
    }
    
    public override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    func animateHeart(){
        setupHeartExplosion()
        heartExplosive.image = UIImage(named: "heartexplode")
        self.view.bringSubviewToFront(heartExplosive)
        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 1, options: [], animations: {
            
            self.heartExplosive.transform = CGAffineTransform(scaleX: 50, y: 50)
//            self.heartExplosive.layoutIfNeeded()
        }){ (true) in
            self.keepHeartAnimated()
            self.run(after: 3, completion: {
                self.stopAnimatingHeart()

            })

        }
        
    }
    
    func keepHeartAnimated(){
        
        UIView.animate(withDuration: 0.8, delay: 0, options: [.curveEaseInOut, .autoreverse, .repeat], animations: {
            self.heartExplosive.transform = CGAffineTransform(scaleX: 45, y: 45)
        }) { (true) in
            
        }
    }
    
    func stopAnimatingHeart(){
        monsterGif.loadGif(name: "monsterwait3")
        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
            self.heartExplosive.transform = CGAffineTransform(scaleX: 0, y: 0)
        }) { (true) in
//            self.animateMonsterParachute()
            if self.monsterCalled == "saddy"{
                
            
            self.testImage.loadGif(name: "monsterpet")
//            self.animateMonsterParachute2()
            }
            
            if self.monsterCalled == "lony"{
                
                
                self.testImage.loadGif(name: "monsterpet2")
                //            self.animateMonsterParachute2()
            }
            
            UIView.animate(withDuration: 0.5, delay: 0.2, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
                self.guideTextTopConstraint.constant = -70
                self.view.layoutIfNeeded()
            }, completion: { (true) in
                self.dangerLabel.text = "Current analysis: safe"
                self.guideText.text = "Good Job! You saved a life!"
                
                UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
                    self.guideTextTopConstraint.constant = 50
                    self.view.layoutIfNeeded()
                })
                UIView.animate(withDuration: 0.5, delay: 0.8, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
                    self.dangerLabelTopConstraint.constant = 140
                    self.view.layoutIfNeeded()
                })
                
            })
        }
    }
    
    func setupHeartExplosion (){
        
        view.addSubview(heartExplosive)
//        view.sendSubviewToBack(heartExplosive)
        
        heartExplosive.contentMode = .scaleAspectFill
//        heartExplosive.backgroundColor = .blue
        
        heartExplosive.translatesAutoresizingMaskIntoConstraints = false
        heartExplosive.widthAnchor.constraint(equalToConstant: 10).isActive = true
        heartExplosive.heightAnchor.constraint(equalToConstant: 10).isActive = true
//        heartExplosive.centerXAnchor.constraint(equalTo: monsterGif.centerXAnchor).isActive=true
        heartExplosive.centerYAnchor.constraint(equalTo: monsterGif.centerYAnchor).isActive=true
        heartExplosive.centerXAnchor.constraint(equalTo: monsterGif.centerXAnchor, constant: -170).isActive=true
        
        
        
    }
    
    func setupCallButton(){
        foodListView.addSubview(callButton)
        
        callButton.backgroundColor = .white
        callButton.layer.borderWidth = 5
        callButton.layer.cornerRadius = 25
        callButton.frame = CGRect(x: 0, y: -10, width: 200, height: 70)
        callButton.setTitle("Call", for: .normal)
        callButton.setTitleColor(.black, for: .normal)
        callButton.titleLabel?.font = UIFont(name: "arial", size: 50)
        
        callButton.addTarget(self, action: #selector(LiveViewController_1_3.unhighlight(sender:)), for: .touchUpInside)
        callButton.addTarget(self, action: #selector(LiveViewController_1_3.highlight(sender:)), for: .touchDown)
        
        callButton.addTarget(self, action: #selector(LiveViewController_1_3.start(sender:)), for: .touchUpInside)
        
        
        callButton.translatesAutoresizingMaskIntoConstraints = false
        callButton.leadingAnchor.constraint(equalTo: foodListView.leadingAnchor, constant: 40).isActive = true
        callButton.trailingAnchor.constraint(equalTo: foodListView.trailingAnchor, constant: -40).isActive = true
        //        startButton.bottomAnchor.constraint(equalTo: timeProgress.topAnchor).isActive=true
        callButton.bottomAnchor.constraint(equalTo: foodListView.bottomAnchor, constant: -40).isActive = true
        callButton.topAnchor.constraint(equalTo: foodListView.topAnchor, constant: 40).isActive = true
        //        callButton.heightAnchor.constraint(equalToConstant: 70).isActive = true
        
    }
    
    func setupNumbersCollectionView(){
    
        numbersCollectionView.register(NumberCell.self, forCellWithReuseIdentifier: cellId)
        phoneView.addSubview(numbersCollectionView)
        numbersCollectionView.layer.cornerRadius = 15
        numbersCollectionView.backgroundColor = .clear
        numbersCollectionView.backgroundColor = .clear
        numbersCollectionView.translatesAutoresizingMaskIntoConstraints = false
        numbersCollectionView.leadingAnchor.constraint(equalTo: phoneView.leadingAnchor, constant: 30).isActive = true
        numbersCollectionView.trailingAnchor.constraint(equalTo: phoneView.trailingAnchor, constant: -30).isActive = true
        numbersCollectionView.bottomAnchor.constraint(equalTo: phoneView.bottomAnchor, constant: -150).isActive = true
        numbersCollectionView.topAnchor.constraint(equalTo: numberVisorLabel.bottomAnchor, constant: 20).isActive = true
        
        
        
    }
    
    
    public func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        numberAtIndex = numbersArray[indexPath.item]
        
        if (numberVisorLabel.text?.characters.count)! < 5 {
        numberVisorLabel.text = numberVisorLabel.text! + String(numberAtIndex)
        }
        
    }
    
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 9
    }
    
    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = numbersCollectionView.dequeueReusableCell(withReuseIdentifier: cellId, for: indexPath) as! NumberCell
        cell.number.text = "\(numbersArray[indexPath.item])"
        return cell
    }
    
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (numbersCollectionView.bounds.width / 3) - 10, height: numbersCollectionView.bounds.width / 3)
    }
    
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0.5
        
    }
    
    func setupStartButton(){
        phoneView.addSubview(startButton)
        
        startButton.setBackgroundImage(UIImage(named: "phoneup2"), for: .normal)
        startButton.contentMode = .scaleAspectFit
        
        startButton.backgroundColor = .white
        startButton.layer.borderWidth = 5
        startButton.layer.cornerRadius = 55
        startButton.frame = CGRect(x: 0, y: -10, width: 200, height: 70)
        
        startButton.titleLabel?.font = UIFont(name: "arial", size: 50)
        
        startButton.addTarget(self, action: #selector(LiveViewController_1_3.unhighlight2(sender:)), for: .touchUpInside)
        startButton.addTarget(self, action: #selector(LiveViewController_1_3.highlight2(sender:)), for: .touchDown)
        
        startButton.addTarget(self, action: #selector(LiveViewController_1_3.start2(sender:)), for: .touchUpInside)
        
        
        startButton.translatesAutoresizingMaskIntoConstraints = false
//        startButton.leadingAnchor.constraint(equalTo: deleteButton.trailingAnchor, constant: 30).isActive = true
        startButton.widthAnchor.constraint(equalToConstant: 110).isActive = true
        startButton.trailingAnchor.constraint(equalTo: phoneView.trailingAnchor, constant: -30).isActive = true
        //        startButton.bottomAnchor.constraint(equalTo: timeProgress.topAnchor).isActive=true
        startButton.bottomAnchor.constraint(equalTo: phoneView.bottomAnchor, constant: -30).isActive = true
        startButton.topAnchor.constraint(equalTo: numbersCollectionView.bottomAnchor, constant: 10).isActive = true
//        callButton.heightAnchor.constraint(equalToConstant: 70).isActive = true
        
    }
    
    func setupDeleteButton(){
        phoneView.addSubview(deleteButton)
        
        deleteButton.setBackgroundImage(UIImage(named: "phonedown2"), for: .normal)
        deleteButton.contentMode = .scaleAspectFit
        
        deleteButton.backgroundColor = .white
        deleteButton.layer.borderWidth = 5
        deleteButton.layer.cornerRadius = 55
        deleteButton.frame = CGRect(x: 0, y: -10, width: 200, height: 70)
        
        deleteButton.titleLabel?.font = UIFont(name: "arial", size: 50)
        
        deleteButton.addTarget(self, action: #selector(LiveViewController_1_3.unhighlight3(sender:)), for: .touchUpInside)
        deleteButton.addTarget(self, action: #selector(LiveViewController_1_3.highlight3(sender:)), for: .touchDown)
        
        deleteButton.addTarget(self, action: #selector(LiveViewController_1_3.start3(sender:)), for: .touchUpInside)
        
        
        deleteButton.translatesAutoresizingMaskIntoConstraints = false
                deleteButton.leadingAnchor.constraint(equalTo: phoneView.leadingAnchor, constant: 30).isActive = true
        deleteButton.widthAnchor.constraint(equalToConstant: 110).isActive = true
//        deleteButton.trailingAnchor.constraint(equalTo: startButton.leadingAnchor, constant: -30).isActive = true
        //        startButton.bottomAnchor.constraint(equalTo: timeProgress.topAnchor).isActive=true
        deleteButton.bottomAnchor.constraint(equalTo: phoneView.bottomAnchor, constant: -30).isActive = true
        deleteButton.topAnchor.constraint(equalTo: numbersCollectionView.bottomAnchor, constant: 10).isActive = true
        //        callButton.heightAnchor.constraint(equalToConstant: 70).isActive = true
        
    }
    
    @objc func highlight3 (sender: UIButton!) {
        deleteButton.backgroundColor = .gray
    }
    @objc func unhighlight3 (sender: UIButton!) {
        deleteButton.backgroundColor = .white
    }
    @objc func start3 (sender: UIButton!) {
        numberVisorLabel.text = ""
        
    }
    
    @objc func highlight (sender: UIButton!) {
        callButton.backgroundColor = .gray
    }
    @objc func unhighlight (sender: UIButton!) {
        callButton.backgroundColor = .white
    }
    @objc func start (sender: UIButton!) {

        animateListViewDown()
        
    }
    @objc func highlight2 (sender: UIButton!) {
        startButton.backgroundColor = .gray
    }
    @objc func unhighlight2 (sender: UIButton!) {
        startButton.backgroundColor = .white
    }
    @objc func start2 (sender: UIButton!) {
        
        let numberCalled = Int(numberVisorLabel.text!)
        
        if numberCalled == lonyNumber {
            print ("ligou para lony")
            monsterCalled = "lony"
            testImage.loadGif(name: "monsterwait2")
            disablePhone()
            animatePhoneDown()
            run(after: 2) {
                self.animateMonsterLeft()
                self.animateTest()
            }
        } else if numberCalled == saddyNumber {
            print ("ligou para saddy")
            monsterCalled = "saddy"
            testImage.loadGif(name: "monsterwait")
            disablePhone()
            animatePhoneDown()
            run(after: 2) {
                self.animateMonsterLeft()
                self.animateTest()
            }
        } else {
            phoneShake()
        }
        
    }
    
    func disablePhone(){
        numbersCollectionView.isUserInteractionEnabled = false
        phoneView.isUserInteractionEnabled = false
        startButton.isUserInteractionEnabled = false
        deleteButton.isUserInteractionEnabled = false
        
        UIView.animate(withDuration: 0.5) {
            self.phoneView.backgroundColor = .gray
            self.startButton.backgroundColor = .gray
            self.deleteButton.backgroundColor = .gray

        }

    }
    
    func animatePhoneDown(){
        UIView.animate(withDuration: 2, delay: 0.5, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
            
            self.phoneView.transform = CGAffineTransform(translationX: 0, y: 800)
            
        })
    }
    
    func phoneShake(){
        UIView.animate(withDuration: 0.3, delay: 0, usingSpringWithDamping: 0, initialSpringVelocity: 1, options: [], animations: {
            
            self.phoneView.transform = CGAffineTransform(translationX: -10, y: 0)
            self.phoneView.transform = CGAffineTransform(translationX: 0, y: 0)
            self.phoneView.transform = CGAffineTransform(translationX: 10, y: 0)
            
            
        }) { (true) in
            self.phoneView.transform = CGAffineTransform(translationX: 0, y: 0)
            
        }

    }
    
    func animateListViewDown() {
        UIView.animate(withDuration: 1, animations: {
            self.foodListBottomConstraint.constant = 600
            self.view.layoutIfNeeded()
        }) { (true) in
           self.animatePhoneView()
        }
    }
    
    func setupNumberVisor() {
        phoneView.addSubview(numberVisorLabel)
        numberVisorLabel.text = ""
        numberVisorLabel.backgroundColor = .clear
        numberVisorLabel.layer.cornerRadius = 15
        numberVisorLabel.layer.borderWidth = 4
        numberVisorLabel.layer.borderColor = UIColor.black.cgColor
        numberVisorLabel.textAlignment = .center
        numberVisorLabel.font = numberVisorLabel.font.withSize(40)
        numberVisorLabel.adjustsFontSizeToFitWidth = true
        
        numberVisorLabel.translatesAutoresizingMaskIntoConstraints = false
        numberVisorLabel.topAnchor.constraint(equalTo: phoneView.topAnchor, constant: 60).isActive=true
        numberVisorLabel.leadingAnchor.constraint(equalTo: phoneView.leadingAnchor, constant: 30).isActive=true
        numberVisorLabel.trailingAnchor.constraint(equalTo: phoneView.trailingAnchor, constant: -30).isActive=true
        numberVisorLabel.heightAnchor.constraint(equalToConstant: 100).isActive=true
        
    }
    
    func setupPhoneView(){
       view.addSubview(phoneView)
        phoneView.backgroundColor = .white
        phoneView.layer.cornerRadius = 15
        phoneView.layer.borderColor = UIColor.black.cgColor
        phoneView.layer.borderWidth = 6
        
        phoneView.translatesAutoresizingMaskIntoConstraints = false
        phoneView.widthAnchor.constraint(equalToConstant: 400).isActive=true
        phoneView.heightAnchor.constraint(equalToConstant: 700).isActive=true
        phoneView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive=true
//        phoneView.heightAnchor.constraint(equalToConstant: view.bounds.height * 0.7).isActive = true
        phoneViewBottomConstraint = phoneView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: 700)
        phoneViewBottomConstraint.isActive=true
        
    }
    
    func animatePhoneView(){
        UIView.animate(withDuration: 2, delay: 0.3, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseOut, animations: {
            self.phoneViewBottomConstraint.constant = -80
            self.view.layoutIfNeeded()
        })
    }
    
    func appear(xamo: UIView){
        
        setupFarBackground(xama: xamo)
//        setupBackground(xama: xamo)
        setupClouds(xama: xamo)
        
        setuptest()
        setupMonsterCar()


        self.run(after: 1) {
//            self.animateClouds(xama: xamo)
            print("cu cagado")
            //
            //            self.animateClouds2(xama: xamo)
        }
        
    }
    
    func animateClouds(xama: UIView){
        UIView.animate(withDuration: 3, delay: 0, options: [.autoreverse, .repeat, .curveEaseInOut], animations: {
            self.cloudsBottomConstraint.constant = 20
            xama.layoutIfNeeded()
        })
    }
    
    func setupMonster(xama: UIView){
        xama.addSubview(monsterGif)
        xama.sendSubviewToBack(monsterGif)
        monsterGif.backgroundColor = .clear
        
        setupMonsterConstraints(xama: view)
    }
    
    
    func setupMonsterConstraints(xama: UIView){
        monsterGif.translatesAutoresizingMaskIntoConstraints = false
        monsterGif.widthAnchor.constraint(equalToConstant: 350).isActive=true
        monsterGif.heightAnchor.constraint(equalToConstant: 350).isActive=true
        //        monsterGif.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive=true
        monsterGif.bottomAnchor.constraint(equalTo: xama.bottomAnchor, constant: -250).isActive=true
        monsterGif.centerXAnchor.constraint(equalTo: xama.centerXAnchor).isActive = true
    }
    
    func setupClouds(xama: UIView){
        xama.addSubview(clouds)
        xama.sendSubviewToBack(clouds)
        
        run(after: 1) {
            self.clouds.loadGif(name: "clouditzy")
            
        }
        
        //        clouds.backgroundColor = .green
        clouds.translatesAutoresizingMaskIntoConstraints = false
        clouds.heightAnchor.constraint(equalToConstant: 260).isActive=true
        clouds.topAnchor.constraint(equalTo: xama.topAnchor, constant: 180).isActive = true
        clouds.widthAnchor.constraint(equalToConstant: 1500).isActive = true
        cloudsBottomConstraint = clouds.leadingAnchor.constraint(equalTo: xama.leadingAnchor, constant: -20)
        cloudsBottomConstraint.isActive=true
        
    }
    
    func setupFarBackground(xama: UIView){
        xama.addSubview(farBackground)
        xama.sendSubviewToBack(farBackground)
        farBackground.clipsToBounds = false
        
        farBackground.translatesAutoresizingMaskIntoConstraints = false
        farBackground.heightAnchor.constraint(equalTo: xama.heightAnchor, multiplier: 0.5).isActive = true
        farBackground.widthAnchor.constraint(equalTo: xama.widthAnchor).isActive = true
        farBackground.bottomAnchor.constraint(equalTo: xama.bottomAnchor).isActive = true
        farBackground.trailingAnchor.constraint(equalTo: xama.trailingAnchor).isActive = true
        
    }
    
    func setupBackground(xama: UIView){
        xama.addSubview(background)
        xama.sendSubviewToBack(background)
        
        background.translatesAutoresizingMaskIntoConstraints = false
        background.heightAnchor.constraint(equalTo: xama.heightAnchor).isActive=true
        background.widthAnchor.constraint(equalTo: xama.widthAnchor).isActive=true
        background.bottomAnchor.constraint(equalTo: xama.bottomAnchor).isActive=true
        background.trailingAnchor.constraint(equalTo: xama.trailingAnchor).isActive=true
    }
    
    func setupDangerLabel(xama: UIView){
        xama.addSubview(dangerLabel)
        xama.bringSubviewToFront(dangerLabel)
        
        dangerLabel.text = "Current analysis: \(currentAnalysis)"
        dangerLabel.textAlignment = .center
        dangerLabel.font = dangerLabel.font.withSize(30)
        
        dangerLabel.translatesAutoresizingMaskIntoConstraints = false
        dangerLabelTopConstraint = dangerLabel.topAnchor.constraint(equalTo: xama.topAnchor, constant: -70)
        dangerLabelTopConstraint.isActive = true
        dangerLabel.leadingAnchor.constraint(equalTo: xama.leadingAnchor, constant: 20).isActive=true
        dangerLabel.trailingAnchor.constraint(equalTo: xama.trailingAnchor, constant: -20).isActive=true
        dangerLabel.heightAnchor.constraint(equalToConstant: 50).isActive = true
    }
    
    func run(after seconds: Int, completion: @escaping () -> Void) {
        let deadline = DispatchTime.now() + .seconds(seconds)
        DispatchQueue.main.asyncAfter(deadline: deadline) {
            completion()
        }
        
    }
    
    func animateDangerText2 (view: UIView, dangerLabelConstraint: NSLayoutConstraint) -> Void{
        
        UIView.animate(withDuration: 1, delay: 0.1, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
            
            dangerLabelConstraint.constant = 140
            view.layoutIfNeeded()
            
        }, completion: { (true) in
            self.run(after: 2, completion: {
                UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
                    dangerLabelConstraint.constant = -70
                    view.layoutIfNeeded()
                    
                    print ("caguei mole e a bosta escorreu")
                    
                })
            })
        })
        
    }
    
    func setupFoodList(xama: UIView){
        xama.addSubview(foodListView)
        foodListView.backgroundColor = .white
        foodListView.layer.cornerRadius = 12
        foodListView.layer.borderColor = UIColor.black.cgColor
        foodListView.layer.borderWidth = 4
        //        foodListView.layer.shouldRasterize = false
        //        foodListView.layer.masksToBounds = false
        //        foodListView.dropShadow(color: .red, offSet: CGSize(width: 1000, height: 1000))
        
        setupFoodListCOnstraint(xama: xama)
    }
    
    func setupFoodListCOnstraint(xama: UIView){
        foodListView.translatesAutoresizingMaskIntoConstraints = false
        foodListView.centerXAnchor.constraint(equalTo: xama.centerXAnchor).isActive = true
        foodListView.leadingAnchor.constraint(equalTo: xama.leadingAnchor, constant: 10).isActive = true
        foodListView.trailingAnchor.constraint(equalTo: xama.trailingAnchor, constant: -10).isActive = true
        foodListView.heightAnchor.constraint(equalToConstant: 170).isActive = true
        foodListBottomConstraint = foodListView.bottomAnchor.constraint(equalTo: xama.bottomAnchor, constant: 600)
        foodListBottomConstraint.isActive = true
        
    }
    
    func setupGuideText(xama: UIView){
        xama.addSubview(guideText)
        xama.bringSubviewToFront(guideText)
        
        guideText.text = guideTextText
        guideText.textAlignment = .center
        guideText.font = guideText.font.withSize(70)
        guideText.adjustsFontSizeToFitWidth = true
        
                guideText.backgroundColor = .clear
        
        guideText.translatesAutoresizingMaskIntoConstraints = false
        guideTextTopConstraint = guideText.topAnchor.constraint(equalTo: xama.topAnchor, constant: -70)
        guideTextTopConstraint.isActive = true
        guideText.leadingAnchor.constraint(equalTo: xama.leadingAnchor, constant: 20).isActive=true
        guideText.trailingAnchor.constraint(equalTo: xama.trailingAnchor, constant: -20).isActive=true
        guideText.heightAnchor.constraint(equalToConstant: 70).isActive=true
    }

    func setupMonsterCar(){
        view.addSubview(monsterCar)
        view.bringSubviewToFront(monsterCar)
        monsterCar.backgroundColor = .clear
        monsterCar.image = UIImage(named: "monstercar")
        
        monsterCar.translatesAutoresizingMaskIntoConstraints = false
        
        monsterCarCenterXConstraint = monsterCar.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: 1000)
        monsterCarCenterXConstraint.isActive=true
        monsterCar.centerYAnchor.constraint(equalTo: monsterGif.centerYAnchor, constant: 100).isActive=true
        monsterCar.widthAnchor.constraint(equalToConstant: 300).isActive=true
        monsterCar.heightAnchor.constraint(equalToConstant: 150).isActive=true
        
        
    }
    
    func animateMonsterLeft(){
//        animateMonsterParachute2()
        UIView.animate(withDuration: 3, delay: 0, usingSpringWithDamping: 0.9, initialSpringVelocity: 1, options: .curveEaseOut, animations: {
            self.monsterGif.transform = CGAffineTransform(translationX: -170, y: 0)
//            self.animateMonsterParachute2()
        }){ (true) in

        }
        
    }
    
//    func animateMonsterParachute2(){
//
//        self.monsterParachuteBottomConstraint.constant = -280
//        monsterParachute.setNeedsLayout()
//        UIView.animate(withDuration: 4, delay: 0, usingSpringWithDamping: 0.9, initialSpringVelocity: 1, options: .curveEaseOut, animations: {
//
//            self.view.layoutIfNeeded()
//
//        }) { (true) in
//        self.monsterParachute.contentMode = .bottom
//        self.monsterParachute.loadGif(name: "monsterwait2")
//
//            self.run(after: 1, completion: {
//                self.animateHeart()
//            })
//
//    }
//    }
    
    
    @objc func animateFoodList(xame: UIView) {
        
        if page > 0 {
            foodListBottomConstraint.constant = -80
        }
        
        var delay = TimeInterval()
        if page == 1 {
            delay=1
        }else{
            delay=0
        }
        
        guideTextTopConstraint.constant = 70
        UIView.animate(withDuration: 1, delay: delay, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseOut, animations: {
            xame.layoutIfNeeded()
        }, completion: {_ in
        })
    }
    
    override public func receive(_ message: PlaygroundValue) {
        //        Uncomment the following to be able to receive messages from the Contents.swift playground page. You will need to define the type of your incoming object and then perform any actions with it.
        //
        //        guard case .data(let messageData) = message else { return }
        //        do { if let incomingObject = try NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(messageData) as? /*TypeOfYourObject*/ {
        //
        //                //do something with the incoming object from the playground page here
        //
        //            }
        //        } catch let error { fatalError("\(error) Unable to receive the message from the Playground page") }
        
    }
}





class NumberCell: UICollectionViewCell {
    
    var number: UILabel = {
        let fn = UILabel()
        fn.textAlignment = .center
        fn.font = fn.font.withSize(25)
        return fn
    }()
    
        override var isHighlighted: Bool {
            didSet {
                self.backgroundColor = isHighlighted ? UIColor.gray : .clear
                
            }
        }
    
    
    
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
        
        addSubview(number)
        
        number.translatesAutoresizingMaskIntoConstraints = false
        number.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: 0).isActive = true
        number.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 0).isActive = true
        number.topAnchor.constraint(equalTo: self.topAnchor, constant: 0).isActive = true
        number.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: 0).isActive = true
        
    }
    func setupViews(){
        backgroundColor = .clear
        layer.borderWidth = 5
        layer.cornerRadius = 15
        
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
