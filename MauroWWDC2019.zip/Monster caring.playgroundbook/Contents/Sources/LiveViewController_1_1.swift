//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  Provides supporting functions for setting up a live view.
//

import UIKit
import Foundation
import PlaygroundSupport
import SpriteKit


var currentAnalysis = "Safe"
var page = 1
var downeup = true
var foodCount = 0
var good = 0
var bad = 0
var guideTextText = "Feed the monster: \(foodCount)/3"

public class LiveViewController_1_1: LiveViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    
    
    public override func viewDidAppear(_ animated: Bool) {
        appear(xamo: self.view)
        
        
//        setupDangerLabel()
//        setupGuideText()

    }
    
    public override func viewDidLoad() {

        super.viewDidLoad()
//        setupMonster()
    }
    
    var dangerLabel = UILabel()
    var dangerLabelTopConstraint = NSLayoutConstraint()
    
    var guideText = UILabel()
    var guideTextTopConstraint = NSLayoutConstraint()
    
    var feedButtonBottomConstraint = NSLayoutConstraint()
    var feedButton: UIButton = {
       var buto = UIButton()
        return buto
    }()
    
    var farBackground: UIImageView = {
        var back = UIImageView()
        back.contentMode = .scaleAspectFill
        back.backgroundColor = .clear
        back.image = UIImage(named: "farimage")
        return back
    }()
    
    var cloudsBottomConstraint = NSLayoutConstraint()
    
    var clouds: UIImageView = {
       var clo = UIImageView()
        clo.backgroundColor = .clear
        clo.image = UIImage(named: "Clouds")
        clo.contentMode = .scaleAspectFit
        return clo
    }()
    var background: UIImageView = {
        var back = UIImageView()
        back.contentMode = .scaleAspectFit
        back.backgroundColor = .white
        
//        back.image = UIImage(named: "park")

        return back
    }()
    
    var monsterGif: UIImageView = {
        var gif = UIImageView()
        gif.contentMode = .scaleAspectFit
        gif.loadGif(name: "monsterhungry")
        return gif
    }()
    
    var selectedAtIndex = UIImage()
    let selectedFoodImage: UIImageView = {
        let image = UIImageView()
        image.contentMode = .scaleAspectFit
        return image
    }()
    
    var selectedFoodImageBottomConstraint = NSLayoutConstraint()
    
    var foodNames = ["Anger","Joy", "Guilt", "Denial", "Love", "Hope"]
    var foodImageNames = ["Anger","Joy", "Guilt", "Denial", "Speak", "Acceptance"]
    var foodOutcomes = ["bad","good","bad","bad","good","good"]

    
    lazy var foodCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.dataSource = self
        cv.delegate = self
        cv.isScrollEnabled = true
        return cv
    }()
    
    let cellId = "cellId"
    
    let foodListView = UIView()
    var foodListBottomConstraint: NSLayoutConstraint!
    
    override public func loadView() {
        let view = UIView()
        view.backgroundColor = .white
        self.view = view
        
       
        setupMonster(xama: view)
        setupGuideText(xama: view)
        setupDangerLabel(xama: view)

//        setupSelectedFoodImage()
        setupFoodList(xama: self.view)
        animateFoodList(xame: self.view)
    }
    
    func appear(xamo: UIView){
        
        setupFarBackground(xama: xamo)
        setupClouds(xama: xamo)
        setupBackground(xama: xamo)
        
        run(after: 1) {
//            self.animateClouds(xama: xamo)
            print("cu cagado")
//
//            self.animateClouds2(xama: xamo)
        }
        
    }
    
    func animateClouds(xama: UIView){
        UIView.animate(withDuration: 3, delay: 0, options: [.autoreverse, .repeat, .curveEaseInOut], animations: {
            self.cloudsBottomConstraint.constant = 20
            xama.layoutIfNeeded()
        })
    }
    
    func setupClouds(xama: UIView){
        xama.addSubview(clouds)
        xama.sendSubviewToBack(clouds)
        
        run(after: 1) {
            self.clouds.loadGif(name: "clouditzy")
            
        }
        
//        clouds.backgroundColor = .green
        clouds.translatesAutoresizingMaskIntoConstraints = false
        clouds.heightAnchor.constraint(equalToConstant: 260).isActive=true
        clouds.topAnchor.constraint(equalTo: xama.topAnchor, constant: 180).isActive = true
        clouds.widthAnchor.constraint(equalToConstant: 1500).isActive = true
        cloudsBottomConstraint = clouds.leadingAnchor.constraint(equalTo: xama.leadingAnchor, constant: -20)
        cloudsBottomConstraint.isActive=true
        
    }
    
    func setupDangerLabel(xama: UIView){
        xama.addSubview(dangerLabel)
        xama.bringSubviewToFront(dangerLabel)
        
        dangerLabel.text = "Current analysis: \(currentAnalysis)"
        dangerLabel.textAlignment = .center
        dangerLabel.font = dangerLabel.font.withSize(30)
        
        dangerLabel.translatesAutoresizingMaskIntoConstraints = false
        dangerLabelTopConstraint = dangerLabel.topAnchor.constraint(equalTo: xama.topAnchor, constant: -70)
        dangerLabelTopConstraint.isActive = true
        dangerLabel.leadingAnchor.constraint(equalTo: xama.leadingAnchor, constant: 20).isActive=true
        dangerLabel.trailingAnchor.constraint(equalTo: xama.trailingAnchor, constant: -20).isActive=true
        dangerLabel.heightAnchor.constraint(equalToConstant: 50).isActive = true
    }
    
    func setupGuideText(xama: UIView){
        xama.addSubview(guideText)
        xama.bringSubviewToFront(guideText)
        
        guideText.text = guideTextText
        guideText.textAlignment = .center
        guideText.font = guideText.font.withSize(70)
        guideText.adjustsFontSizeToFitWidth = true

//        guideText.backgroundColor = .blue
        
        guideText.translatesAutoresizingMaskIntoConstraints = false
        guideTextTopConstraint = guideText.topAnchor.constraint(equalTo: xama.topAnchor, constant: -70)
        guideTextTopConstraint.isActive = true
        guideText.leadingAnchor.constraint(equalTo: xama.leadingAnchor, constant: 20).isActive=true
        guideText.trailingAnchor.constraint(equalTo: xama.trailingAnchor, constant: -20).isActive=true
        guideText.heightAnchor.constraint(equalToConstant: 70).isActive=true
    }
    
    func setupFeedButton(xama: UIView){
        xama.addSubview(feedButton)
        xama.sendSubviewToBack(feedButton)
        
        feedButton.translatesAutoresizingMaskIntoConstraints=false
        
        feedButton.backgroundColor = .white
        feedButton.layer.borderWidth = 5
        feedButton.layer.cornerRadius = 12
        feedButton.frame = CGRect(x: 0, y: -10, width: 200, height: 70)
        feedButton.setTitle("Feed", for: .normal)
        feedButton.setTitleColor(.black, for: .normal)
        feedButton.titleLabel?.font = UIFont(name: "arial", size: 25)
        
        feedButton.addTarget(self, action: #selector(LiveViewController_1_1.unhighlight(sender:)), for: .touchUpInside)
        feedButton.addTarget(self, action: #selector(LiveViewController_1_1.highlight(sender:)), for: .touchDown)

        feedButton.addTarget(self, action: #selector(LiveViewController_1_1.feed(sender:)), for: .touchUpInside)
        
        
        feedButton.trailingAnchor.constraint(equalTo: foodListView.trailingAnchor, constant: 0).isActive=true
        feedButtonBottomConstraint = feedButton.bottomAnchor.constraint(equalTo: xama.bottomAnchor, constant: -90)
        feedButtonBottomConstraint.isActive=true
        feedButton.heightAnchor.constraint(equalToConstant: 70).isActive=true
        feedButton.widthAnchor.constraint(equalToConstant: 200).isActive=true
        
    }
    
    @objc func highlight (sender: UIButton!) {
        feedButton.backgroundColor = .gray
    }
    @objc func unhighlight (sender: UIButton!) {
        feedButton.backgroundColor = .white
    }
    @objc func feed (sender: UIButton!) {
        print("MORRE")
        
        guideText.text = "Feed the monster: \(foodCount + 1)/3"
        
        if selectedFoodImage.image == UIImage(named: "Guilt") || selectedFoodImage.image == UIImage(named: "Anger") || selectedFoodImage.image == UIImage(named: "Denial") {
            bad = bad + 1
        }
        if selectedFoodImage.image == UIImage(named: "Joy") || selectedFoodImage.image == UIImage(named: "Speak") || selectedFoodImage.image == UIImage(named: "Acceptance") {
            good = good + 1
        }
        print("Bad: \(bad)   Good: \(good)")
        
        foodCount = foodCount + 1
        downeup = false
        feedButton.isEnabled = false
        feedButton.backgroundColor = .gray
        downAnimateSelected()
        foodCollectionView.isUserInteractionEnabled = false
        
        if foodCount < 3 {
        monsterGif.loadGif(name: "monstereat")
        run(after: 2) {
            self.monsterGif.loadGif(name: "monsterhungry")
            self.feedButton.isEnabled = true
            self.feedButton.backgroundColor = .white
            self.upAnimateSelectedFoodImage()
            self.foodCollectionView.isUserInteractionEnabled = true
        }
        } else if foodCount == 3 {
            
            if bad < good {
                currentAnalysis = "Safe"
                dangerLabel.text = "Current analysis: \(currentAnalysis)"

            }
            if bad > good {
                currentAnalysis = "Dangerous"
                dangerLabel.text = "Current analysis: \(currentAnalysis)"

            }
            
            
            monsterGif.loadGif(name: "monstereat")
            run(after: 2) {
                if currentAnalysis == "Dangerous"{
                    self.monsterGif.loadGif(name: "monsterSad2")
                }else{
                self.monsterGif.loadGif(name: "monsterstand")
                }
                self.foodCollectionView.isUserInteractionEnabled = false
                
                UIView.animate(withDuration: 1, delay: 0.0, usingSpringWithDamping:
                    0.7, initialSpringVelocity: 0.0, options: [], animations: {
                     self.foodListView.backgroundColor = .gray
//                        self.guideText.text = "Now the monster is full"
                }, completion: nil)
                UIView.animate(withDuration: 0.5, delay: 0.2, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
                    self.guideTextTopConstraint.constant = -70
                    self.view.layoutIfNeeded()
                }, completion: { (true) in
                    self.guideText.text = "The monster is full!"
                    
                    UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
                        self.guideTextTopConstraint.constant = 50
                        self.view.layoutIfNeeded()
                    })
                    UIView.animate(withDuration: 0.5, delay: 0.8, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
                        self.dangerLabelTopConstraint.constant = 140
                        self.view.layoutIfNeeded()
                    })
                })
                
            }
        }
    }
    
    func setupFarBackground(xama: UIView){
        xama.addSubview(farBackground)
        xama.sendSubviewToBack(farBackground)
        farBackground.clipsToBounds = false
        
        farBackground.translatesAutoresizingMaskIntoConstraints = false
        farBackground.heightAnchor.constraint(equalTo: xama.heightAnchor, multiplier: 0.5).isActive = true
        farBackground.widthAnchor.constraint(equalTo: xama.widthAnchor).isActive = true
        farBackground.bottomAnchor.constraint(equalTo: xama.bottomAnchor).isActive = true
        farBackground.trailingAnchor.constraint(equalTo: xama.trailingAnchor).isActive = true
        
    }
    
    func setupBackground(xama: UIView){
        xama.addSubview(background)
        xama.sendSubviewToBack(background)
        
        background.translatesAutoresizingMaskIntoConstraints = false
        background.heightAnchor.constraint(equalTo: xama.heightAnchor).isActive=true
        background.widthAnchor.constraint(equalTo: xama.widthAnchor).isActive=true
        background.bottomAnchor.constraint(equalTo: xama.bottomAnchor).isActive=true
        background.trailingAnchor.constraint(equalTo: xama.trailingAnchor).isActive=true
        
//        background.image = UIImage(named: "park")

    }
    
    func setupMonster(xama: UIView){
        xama.addSubview(monsterGif)
        xama.sendSubviewToBack(monsterGif)
        monsterGif.backgroundColor = .clear
        
        setupMonsterConstraints(xama: view)
    }

    
    func setupMonsterConstraints(xama: UIView){
        monsterGif.translatesAutoresizingMaskIntoConstraints = false
        monsterGif.widthAnchor.constraint(equalToConstant: 400).isActive=true
        monsterGif.heightAnchor.constraint(equalToConstant: 400).isActive=true
//        monsterGif.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive=true
        monsterGif.bottomAnchor.constraint(equalTo: xama.bottomAnchor, constant: -250).isActive=true
        monsterGif.centerXAnchor.constraint(equalTo: xama.centerXAnchor).isActive = true
    }
    
     func setupSelectedFoodImage(){
        view.addSubview(selectedFoodImage)
        view.sendSubviewToBack(selectedFoodImage)
        selectedFoodImage.backgroundColor = .clear
        selectedFoodImage.frame.size = CGSize(width: 100, height: 100)
        setupSelectedFoodImageConstraints()
        
    }
    func setupSelectedFoodImageConstraints(){
        selectedFoodImage.translatesAutoresizingMaskIntoConstraints = false
        selectedFoodImage.widthAnchor.constraint(equalToConstant: 200).isActive=true
//        selectedFoodImage.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -550).isActive = true
//        selectedFoodImage.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 550).isActive = true
        selectedFoodImage.heightAnchor.constraint(equalToConstant: 165).isActive = true
//        selectedFoodImage.topAnchor.constraint(equalTo: view.topAnchor, constant: 30).isActive = true
        selectedFoodImageBottomConstraint = selectedFoodImage.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -10)
        selectedFoodImageBottomConstraint.isActive = true
//        selectedFoodImage.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -10.1).isActive = true
        selectedFoodImage.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive=true
        
    }
    
    @objc func upAnimateSelectedFoodImage() {
        selectedFoodImageBottomConstraint.constant = -280
        feedButtonBottomConstraint.constant = -280
        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseOut, animations: {
            self.view.layoutIfNeeded()
        })
    }
    
    @objc func downAnimateSelected(){
        selectedFoodImageBottomConstraint.constant = -80
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
            self.view.layoutIfNeeded()
        }) { (true) in
            self.selectedFoodImage.image = self.selectedAtIndex
            if downeup {
                self.upAnimateSelectedFoodImage()
                
            }
        }
    }
    
    
    
    func setupFoodCollectionView(){
        
        foodCollectionView.register(FoodCell.self, forCellWithReuseIdentifier: cellId)
        foodListView.addSubview(foodCollectionView)
        foodCollectionView.layer.cornerRadius = 12
        foodCollectionView.backgroundColor = .clear
        
        setupFoodCollectionViewConstraint()
    }
    
    func setupFoodCollectionViewConstraint(){
        foodCollectionView.translatesAutoresizingMaskIntoConstraints = false
        foodCollectionView.leadingAnchor.constraint(equalTo: foodListView.leadingAnchor, constant: 20).isActive = true
        foodCollectionView.trailingAnchor.constraint(equalTo: foodListView.trailingAnchor, constant: -20).isActive = true
        foodCollectionView.bottomAnchor.constraint(equalTo: foodListView.bottomAnchor, constant: -30).isActive = true
        foodCollectionView.topAnchor.constraint(equalTo: foodListView.topAnchor, constant: 30).isActive = true
        
    
    }
    
    func setupFoodList(xama: UIView){
        xama.addSubview(foodListView)
        foodListView.backgroundColor = .white
        foodListView.layer.cornerRadius = 12
        foodListView.layer.borderColor = UIColor.black.cgColor
        foodListView.layer.borderWidth = 4
//        foodListView.layer.shouldRasterize = false
//        foodListView.layer.masksToBounds = false
//        foodListView.dropShadow(color: .red, offSet: CGSize(width: 1000, height: 1000))

        setupFoodListCOnstraint(xama: xama)
        
        if page == 1 {
        setupFoodCollectionView()
        }
    }
    
    func setupFoodListCOnstraint(xama: UIView){
        foodListView.translatesAutoresizingMaskIntoConstraints = false
        foodListView.leadingAnchor.constraint(equalTo: xama.leadingAnchor, constant: 10).isActive = true
        foodListView.trailingAnchor.constraint(equalTo: xama.trailingAnchor, constant: -10).isActive = true
        foodListView.heightAnchor.constraint(equalToConstant: 170).isActive = true
        foodListBottomConstraint = foodListView.bottomAnchor.constraint(equalTo: xama.bottomAnchor, constant: 600)
        foodListBottomConstraint.isActive = true
        
    }
    
    @objc func animateFoodList(xame: UIView) {
        
        if page > 0 {
        foodListBottomConstraint.constant = -80
        }
        
        var delay = TimeInterval()
        if page == 1 {
            delay=1
        }else{
            delay=0
        }
        
        guideTextTopConstraint.constant = 70
        UIView.animate(withDuration: 1, delay: delay, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseOut, animations: {
            xame.layoutIfNeeded()
        }, completion: {_ in
            
            if page == 1 {
            self.setupSelectedFoodImage()
            self.setupFeedButton(xama: self.view)
            
            
            UIView.animate(withDuration: 1, delay: 0.1, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
                
                self.dangerLabelTopConstraint.constant = 140
                xame.layoutIfNeeded()
                
            }, completion: { (true) in
                self.run(after: 2, completion: {
                    UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
                        
                        self.dangerLabelTopConstraint.constant = -70
                       xame.layoutIfNeeded()
                        
                    })
                })
            })
            }
//            self.setupBackground()
        })
    }
    
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 6
    }
    
    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = foodCollectionView.dequeueReusableCell(withReuseIdentifier: cellId, for: indexPath) as! FoodCell
        cell.foodName.text = foodNames[indexPath.item]
        cell.foodImage.image = UIImage(named: "\(foodImageNames[indexPath.item])")
//        cell.backgroundColor = UIColor.blue
//        cell.layer.cornerRadius = 12
        
        return cell
    }
    
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 250, height: foodCollectionView.frame.height)
    }
    
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 1
        
    }
    
    public func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
//        let cell = foodCollectionView.dequeueReusableCell(withReuseIdentifier: cellId, for: indexPath) as! FoodCell
        
//        selectedFoodImageBottomConstraint.constant = 600
//        view.layoutIfNeeded()
        downeup=true
       
        view.sendSubviewToBack(monsterGif)
        view.sendSubviewToBack(farBackground)
        view.sendSubviewToBack(clouds)
        view.sendSubviewToBack(background)


        downAnimateSelected()
        selectedAtIndex = UIImage(named: "\(foodImageNames[indexPath.item])")!
//        selectedFoodImage.image = UIImage(named: "\(foodNames[indexPath.item])")
    }
    
    func run(after seconds: Int, completion: @escaping () -> Void) {
        let deadline = DispatchTime.now() + .seconds(seconds)
        DispatchQueue.main.asyncAfter(deadline: deadline) {
            completion()
        }
        
    }
     override public func receive(_ message: PlaygroundValue) {
//        Uncomment the following to be able to receive messages from the Contents.swift playground page. You will need to define the type of your incoming object and then perform any actions with it.
//
//        guard case .data(let messageData) = message else { return }
//        do { if let incomingObject = try NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(messageData) as? /*TypeOfYourObject*/ {
//
//                //do something with the incoming object from the playground page here
//
//            }
//        } catch let error { fatalError("\(error) Unable to receive the message from the Playground page") }
        
    }
}
class FoodCell: UICollectionViewCell {
    
    var foodName: UILabel = {
        let fn = UILabel()
        fn.textAlignment = .center
        fn.font = fn.font.withSize(25)
        return fn
    }()
    let foodImage: UIImageView = {
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFit
        iv.layer.cornerRadius = 12
        iv.layer.borderWidth = 0
        iv.layer.borderColor = UIColor.white.cgColor
        
        return iv
    }()
    
//    override var isHighlighted: Bool {
//        didSet {
//            foodName.textColor = isHighlighted ? UIColor.white : nil
//            foodImage.layer.borderWidth = isHighlighted ? 2 : 0
//        }
//    }
    
    override var isSelected: Bool {
        didSet {
//            self.layer.borderColor = isSelected ? UIColor.blue.cgColor : UIColor.black.cgColor
            self.backgroundColor = isSelected ? UIColor.gray : UIColor.clear

            
            
        }
    }
    
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
        
        addSubview(foodName)
        addSubview(foodImage)
        
        foodImage.translatesAutoresizingMaskIntoConstraints = false
        foodName.translatesAutoresizingMaskIntoConstraints = false
        
        foodImage.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -10).isActive = true
        foodImage.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 10).isActive = true
        foodImage.topAnchor.constraint(equalTo: self.topAnchor, constant: 10).isActive = true
        foodImage.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: -40).isActive = true
        
        foodName.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -10).isActive = true
        foodName.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 10).isActive = true
        foodName.topAnchor.constraint(equalTo: foodImage.bottomAnchor, constant: 0).isActive = true
        foodName.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: -10).isActive = true
        
    }
    func setupViews(){
        backgroundColor = .clear
        layer.borderWidth = 2
        layer.cornerRadius = 12


    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}





















import ImageIO

extension UIImageView {
    
    public func loadGif(name: String) {
        DispatchQueue.global().async {
            let image = UIImage.gif(name: name)
            DispatchQueue.main.async {
                self.image = image
            }
        }
    }
    
    @available(iOS 9.0, *)
    public func loadGif(asset: String) {
        DispatchQueue.global().async {
            let image = UIImage.gif(asset: asset)
            DispatchQueue.main.async {
                self.image = image
            }
        }
    }
    
}


//license for the following code

//The MIT License (MIT)
//
//Copyright (c) 2016 Arne Bahlo
//
//Permission is hereby granted, free of charge, to any person obtaining a copy
//of this software and associated documentation files (the "Software"), to deal
//in the Software without restriction, including without limitation the rights
//to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//copies of the Software, and to permit persons to whom the Software is
//furnished to do so, subject to the following conditions:
//
//The above copyright notice and this permission notice shall be included in all
//copies or substantial portions of the Software.
//
//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//SOFTWARE.

extension UIImage {
    
    public class func gif(data: Data) -> UIImage? {
        guard let source = CGImageSourceCreateWithData(data as CFData, nil) else {
            print("SwiftGif: Source for the image does not exist")
            return nil
        }
        
        return UIImage.animatedImageWithSource(source)
    }
    
    public class func gif(url: String) -> UIImage? {
        // Validate URL
        guard let bundleURL = URL(string: url) else {
            print("SwiftGif: This image named \"\(url)\" does not exist")
            return nil
        }
        
        // Validate data
        guard let imageData = try? Data(contentsOf: bundleURL) else {
            print("SwiftGif: Cannot turn image named \"\(url)\" into NSData")
            return nil
        }
        
        return gif(data: imageData)
    }
    
    public class func gif(name: String) -> UIImage? {
        // Check for existance of gif
        guard let bundleURL = Bundle.main
            .url(forResource: name, withExtension: "gif") else {
                print("SwiftGif: This image named \"\(name)\" does not exist")
                return nil
        }
        
        // Validate data
        guard let imageData = try? Data(contentsOf: bundleURL) else {
            print("SwiftGif: Cannot turn image named \"\(name)\" into NSData")
            return nil
        }
        
        return gif(data: imageData)
    }
    
    @available(iOS 9.0, *)
    public class func gif(asset: String) -> UIImage? {
        // Create source from assets catalog
        guard let dataAsset = NSDataAsset(name: asset) else {
            print("SwiftGif: Cannot turn image named \"\(asset)\" into NSDataAsset")
            return nil
        }
        
        return gif(data: dataAsset.data)
    }
    
    internal class func delayForImageAtIndex(_ index: Int, source: CGImageSource!) -> Double {
        var delay = 0.1
        
        // Get dictionaries
        let cfProperties = CGImageSourceCopyPropertiesAtIndex(source, index, nil)
        let gifPropertiesPointer = UnsafeMutablePointer<UnsafeRawPointer?>.allocate(capacity: 0)
        defer {
            gifPropertiesPointer.deallocate()
        }
        if CFDictionaryGetValueIfPresent(cfProperties, Unmanaged.passUnretained(kCGImagePropertyGIFDictionary).toOpaque(), gifPropertiesPointer) == false {
            return delay
        }
        
        let gifProperties:CFDictionary = unsafeBitCast(gifPropertiesPointer.pointee, to: CFDictionary.self)
        
        // Get delay time
        var delayObject: AnyObject = unsafeBitCast(
            CFDictionaryGetValue(gifProperties,
                                 Unmanaged.passUnretained(kCGImagePropertyGIFUnclampedDelayTime).toOpaque()),
            to: AnyObject.self)
        if delayObject.doubleValue == 0 {
            delayObject = unsafeBitCast(CFDictionaryGetValue(gifProperties,
                                                             Unmanaged.passUnretained(kCGImagePropertyGIFDelayTime).toOpaque()), to: AnyObject.self)
        }
        
        if let delayObject = delayObject as? Double, delayObject > 0 {
            delay = delayObject
        } else {
            delay = 0.1 // Make sure they're not too fast
        }
        
        return delay
    }
    
    internal class func gcdForPair(_ a: Int?, _ b: Int?) -> Int {
        var a = a
        var b = b
        // Check if one of them is nil
        if b == nil || a == nil {
            if b != nil {
                return b!
            } else if a != nil {
                return a!
            } else {
                return 0
            }
        }
        
        // Swap for modulo
        if a! < b! {
            let c = a
            a = b
            b = c
        }
        
        // Get greatest common divisor
        var rest: Int
        while true {
            rest = a! % b!
            
            if rest == 0 {
                return b! // Found it
            } else {
                a = b
                b = rest
            }
        }
    }
    
    internal class func gcdForArray(_ array: Array<Int>) -> Int {
        if array.isEmpty {
            return 1
        }
        
        var gcd = array[0]
        
        for val in array {
            gcd = UIImage.gcdForPair(val, gcd)
        }
        
        return gcd
    }
    
    internal class func animatedImageWithSource(_ source: CGImageSource) -> UIImage? {
        let count = CGImageSourceGetCount(source)
        var images = [CGImage]()
        var delays = [Int]()
        
        // Fill arrays
        for i in 0..<count {
            // Add image
            if let image = CGImageSourceCreateImageAtIndex(source, i, nil) {
                images.append(image)
            }
            
            // At it's delay in cs
            let delaySeconds = UIImage.delayForImageAtIndex(Int(i),
                                                            source: source)
            delays.append(Int(delaySeconds * 1000.0)) // Seconds to ms
        }
        
        // Calculate full duration
        let duration: Int = {
            var sum = 0
            
            for val: Int in delays {
                sum += val
            }
            
            return sum
        }()
        
        // Get frames
        let gcd = gcdForArray(delays)
        var frames = [UIImage]()
        
        var frame: UIImage
        var frameCount: Int
        for i in 0..<count {
            frame = UIImage(cgImage: images[Int(i)])
            frameCount = Int(delays[Int(i)] / gcd)
            
            for _ in 0..<frameCount {
                frames.append(frame)
            }
        }
        
        // Heyhey
        let animation = UIImage.animatedImage(with: frames,
                                              duration: Double(duration) / 1000.0)
        
        return animation
    }
    
}




