//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  Provides supporting functions for setting up a live view.
//

import UIKit
import Foundation
import PlaygroundSupport
import ImageIO

var pageend = false


public class LiveViewController_1_2: LiveViewController {
    var touchEnd = UIGestureRecognizer()
    var isMoving = UILongPressGestureRecognizer()
    var timesToSwipe = 10
    
    
    var timer:Timer?
    var timeLeft = 15
    
    var countDownLabel = UILabel()
    var count = 10
    
    let startButton = UIButton()
    
    let timeProgress = UIProgressView()
    
    let emitterCell: CAEmitterCell = {
        let emi = CAEmitterCell()
        emi.birthRate = 0
        return emi
    }()
    
    var dangerLabel = UILabel()
    var dangerLabelTopConstraint = NSLayoutConstraint()
    
    var guideText = UILabel()
    var guideTextTopConstraint = NSLayoutConstraint()
    
    var feedButtonBottomConstraint = NSLayoutConstraint()
    var feedButton: UIButton = {
        var buto = UIButton()
        return buto
    }()
    
    var farBackground: UIImageView = {
        var back = UIImageView()
        back.contentMode = .scaleAspectFill
        back.backgroundColor = .clear
        back.image = UIImage(named: "farimage")
        return back
    }()
    
    var cloudsBottomConstraint = NSLayoutConstraint()
    
    var clouds: UIImageView = {
        var clo = UIImageView()
        clo.backgroundColor = .clear
        clo.image = UIImage(named: "Clouds")
        clo.contentMode = .scaleAspectFit
        return clo
    }()
    var background: UIImageView = {
        var back = UIImageView()
        back.contentMode = .scaleAspectFit
        back.backgroundColor = .white
        
        //        back.image = UIImage(named: "park")
        
        return back
    }()
    
    var monsterGif: UIImageView = {
        var gif = UIImageView()
        gif.contentMode = .scaleAspectFit
        gif.loadGif(name: "monsterwait2")
        return gif
    }()
    
    var selectedAtIndex = UIImage()
    let selectedFoodImage: UIImageView = {
        let image = UIImageView()
        image.contentMode = .scaleAspectFit
        return image
    }()
    
    let foodListView = UIView()
    var foodListBottomConstraint: NSLayoutConstraint!
    
    
    
    
    public override func viewDidAppear(_ animated: Bool) {
        
        setupCountDownLabel()
        setupStartButton()
        appear(xamo: self.view)
        
        self.run(after: 1) {
            self.animateDangerText2(view: self.view, dangerLabelConstraint: self.dangerLabelTopConstraint)
        }
        
        
    }
    
    public override func loadView() {
        let view3 = UIView()
        view3.backgroundColor = .white
        self.view = view3
        
        page = 2
        guideTextText = "Pet the monster"
        
        setupMonster(xama: view)
        setupGuideText(xama: view)
        setupDangerLabel(xama: view)
        
        //        setupSelectedFoodImage()
        self.setupFoodList(xama: self.view)
        self.animateFoodList(xame: self.view)
        
        
    }
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        setupGestures()
        
    }
    
    @objc func highlight (sender: UIButton!) {
        startButton.backgroundColor = .gray
    }
    @objc func unhighlight (sender: UIButton!) {
        startButton.backgroundColor = .white
    }
    @objc func start (sender: UIButton!) {
        
        monsterGif.isUserInteractionEnabled = true
        
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateCountdown), userInfo: nil, repeats: true)
        
        UIView.animate(withDuration: 0.25, delay: 0, options: [], animations: {
            self.startButton.alpha = 0
        }) { (true) in
            self.setupTimeProgress()
            UIView.animate(withDuration: 0.25, delay: 0, options: [], animations: {
                self.timeProgress.alpha = 1
            })
        }
        
    }
    
    func setupTimeProgress() {
        foodListView.addSubview(timeProgress)
        
        timeProgress.alpha = 0
        timeProgress.backgroundColor = .white
        timeProgress.tintColor = .clear
        timeProgress.layer.borderColor = UIColor.black.cgColor
        timeProgress.layer.borderWidth = 4
        timeProgress.layer.cornerRadius = 25
        timeProgress.progress = 0
        timeProgress.clipsToBounds = true
        timeProgress.progressTintColor = .black
        timeProgress.trackTintColor = .white
        
        timeProgress.translatesAutoresizingMaskIntoConstraints = false
        timeProgress.leadingAnchor.constraint(equalTo: foodListView.leadingAnchor, constant: 20).isActive = true
        timeProgress.trailingAnchor.constraint(equalTo: foodListView.trailingAnchor, constant: -20).isActive = true
        
        timeProgress.bottomAnchor.constraint(equalTo: foodListView.bottomAnchor, constant: -20).isActive = true
        timeProgress.heightAnchor.constraint(equalToConstant: 70).isActive = true
    }
    
    func increaseProgress (){
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 1, options: .curveEaseOut, animations: {
            self.timeProgress.setProgress(self.timeProgress.progress + 0.001, animated: true)
        })
        if self.timeProgress.progress == 1 {
            monsterGif.removeGestureRecognizer(isMoving)
            monsterGif.isUserInteractionEnabled = false
            monsterGif.loadGif(name: "monsterpet2")
            //            pageend = true
            timer?.invalidate()
            
            countDownLabel.text = "Pleasure Frenzy!"
            UIView.animate(withDuration: 0.5, delay: 0, animations: {
                self.countDownLabel.textColor = .white
                self.foodListView.backgroundColor = .gray
                self.timeProgress.backgroundColor = .gray
                self.timeProgress.trackTintColor = .gray
                
            })
            
            UIView.animate(withDuration: 0.5, delay: 0.2, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
                self.guideTextTopConstraint.constant = -70
                self.view.layoutIfNeeded()
            }, completion: { (true) in
                self.guideText.text = "Good Job! The monster is pleased by you!"
                
                UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
                    self.guideTextTopConstraint.constant = 50
                    self.view.layoutIfNeeded()
                })
                UIView.animate(withDuration: 0.5, delay: 0.8, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
                    self.dangerLabelTopConstraint.constant = 140
                    self.view.layoutIfNeeded()
                })
                
            })
        }
        
    }
    
    func setupCountDownLabel() {
        foodListView.addSubview(countDownLabel)
        foodListView.bringSubviewToFront(countDownLabel)
        
        countDownLabel.backgroundColor = .clear
        countDownLabel.text = "15 seconds left"
        countDownLabel.textAlignment = .center
        countDownLabel.font = countDownLabel.font.withSize(70)
        countDownLabel.adjustsFontSizeToFitWidth = true
        
        countDownLabel.translatesAutoresizingMaskIntoConstraints = false
        countDownLabel.topAnchor.constraint(equalTo: foodListView.topAnchor, constant: 20)
        countDownLabel.leadingAnchor.constraint(equalTo: foodListView.leadingAnchor, constant: 20).isActive = true
        countDownLabel.trailingAnchor.constraint(equalTo: foodListView.trailingAnchor, constant: -20).isActive = true
        countDownLabel.heightAnchor.constraint(equalToConstant: 70)
    }
    
    func heartExplosion() {
        let emitter = CAEmitterLayer()
        view?.layer.addSublayer(emitter)
        emitter.emitterShape = CAEmitterLayerEmitterShape.rectangle
        
        print ("tamanho: \(self.view.bounds.height)")
        
        if self.view.bounds.height <= 1024 {
            emitter.emitterPosition = CGPoint(x: view.bounds.width/2, y: (view.bounds.height/2) - 30)
        } else {
            emitter.emitterPosition = CGPoint(x: view.bounds.width/2, y: (view.bounds.height/2) + 100)
        }
        
        let emitterCell = CAEmitterCell()
        emitterCell.contents = UIImage(named: "heart.png")?.cgImage
        
        emitterCell.birthRate = 1
        emitterCell.lifetime = 1.5
        emitter.emitterCells = [emitterCell]
        emitterCell.yAcceleration = -100.0
        emitterCell.xAcceleration = 3.0
        emitterCell.velocity = 10.0
        emitterCell.emissionLongitude = .pi * -0.5
        emitterCell.velocityRange = 200.0
        emitterCell.emissionRange = .pi * 0.5
        
        if pageend == false {
            run(after: 1) {
                emitter.birthRate = 0
            }
            
        }
    }
    
    func setupStartButton(){
        foodListView.addSubview(startButton)
        
        startButton.backgroundColor = .white
        startButton.layer.borderWidth = 5
        startButton.layer.cornerRadius = 25
        startButton.frame = CGRect(x: 0, y: -10, width: 200, height: 70)
        startButton.setTitle("Start", for: .normal)
        startButton.setTitleColor(.black, for: .normal)
        startButton.titleLabel?.font = UIFont(name: "arial", size: 35)
        
        startButton.addTarget(self, action: #selector(LiveViewController_1_2.unhighlight(sender:)), for: .touchUpInside)
        startButton.addTarget(self, action: #selector(LiveViewController_1_2.highlight(sender:)), for: .touchDown)
        
        startButton.addTarget(self, action: #selector(LiveViewController_1_2.start(sender:)), for: .touchUpInside)
        
        
        startButton.translatesAutoresizingMaskIntoConstraints = false
        startButton.leadingAnchor.constraint(equalTo: foodListView.leadingAnchor, constant: 20).isActive = true
        startButton.trailingAnchor.constraint(equalTo: foodListView.trailingAnchor, constant: -20).isActive = true
        //        startButton.bottomAnchor.constraint(equalTo: timeProgress.topAnchor).isActive=true
        startButton.bottomAnchor.constraint(equalTo: foodListView.bottomAnchor, constant: -20).isActive = true
        startButton.heightAnchor.constraint(equalToConstant: 70).isActive = true
        
    }
    
    @objc func updateCountdown(){
        timeLeft -= 1
        countDownLabel.text = "\(timeLeft) seconds left"
        
        if timeLeft <= 0 {
            timer?.invalidate()
            timer = nil
            countDownLabel.text = "Time's up!"
            countDownLabel.textColor = .white
            
            monsterGif.removeGestureRecognizer(isMoving)
            
            self.monsterGif.isUserInteractionEnabled = false
            UIView.animate(withDuration: 0.5, delay: 0, animations: {
                
                self.foodListView.backgroundColor = .gray
                self.timeProgress.backgroundColor = .gray
                self.timeProgress.trackTintColor = .gray
                
            }) { (true) in
                self.run(after: Int(0.5), completion: {
                    self.monsterGif.loadGif(name: "monstercry")
                })
            }
            
            
            UIView.animate(withDuration: 0.5, delay: 0.2, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
                self.guideTextTopConstraint.constant = -70
                self.view.layoutIfNeeded()
            }, completion: { (true) in
                self.guideText.text = "Oops, try giving the monster more attention next time."
                self.dangerLabel.text = "Current analysis: Dangerous"
                
                UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
                    self.guideTextTopConstraint.constant = 50
                    self.view.layoutIfNeeded()
                })
                UIView.animate(withDuration: 0.5, delay: 0.8, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
                    self.dangerLabelTopConstraint.constant = 140
                    self.view.layoutIfNeeded()
                })
                
            })
        }
    }
    
    func setupGestures(){
        
        
        isMoving = UILongPressGestureRecognizer(target: self, action: #selector(LiveViewController_1_2.isMovingFunc))
        isMoving.minimumPressDuration = 0
        monsterGif.addGestureRecognizer(isMoving)
    }
    
    @objc func isMovingFunc(){
        
        if isMoving.state == .began {
            monsterGif.loadGif(name: "monsterpet2")
        }
        
        increaseProgress()
        
        let generator = UINotificationFeedbackGenerator()
        generator.prepare()
        generator.notificationOccurred(.success)
        
        
        heartExplosion()
        
        
        if isMoving.state == .ended {
            monsterGif.loadGif(name: "monsterwait2")
        }
        
    }
    
    func appear(xamo: UIView){
        
        setupFarBackground(xama: xamo)
//        setupBackground(xama: xamo)
        setupClouds(xama: xamo)

        self.run(after: 1) {
//            self.animateClouds(xama: xamo)
            print("cu cagado")
            //
            //            self.animateClouds2(xama: xamo)
        }
        
    }
    
    func animateClouds(xama: UIView){
        UIView.animate(withDuration: 3, delay: 0, options: [.autoreverse, .repeat, .curveEaseInOut], animations: {
            self.cloudsBottomConstraint.constant = 20
            xama.layoutIfNeeded()
        })
    }
    
    func setupMonster(xama: UIView){
        xama.addSubview(monsterGif)
        xama.sendSubviewToBack(monsterGif)
        monsterGif.backgroundColor = .clear
        
        setupMonsterConstraints(xama: view)
    }
    
    
    func setupMonsterConstraints(xama: UIView){
        monsterGif.translatesAutoresizingMaskIntoConstraints = false
        monsterGif.widthAnchor.constraint(equalToConstant: 400).isActive=true
        monsterGif.heightAnchor.constraint(equalToConstant: 400).isActive=true
        //        monsterGif.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive=true
        monsterGif.bottomAnchor.constraint(equalTo: xama.bottomAnchor, constant: -250).isActive=true
        monsterGif.centerXAnchor.constraint(equalTo: xama.centerXAnchor).isActive = true
    }
    
    func setupClouds(xama: UIView){
        xama.addSubview(clouds)
        xama.sendSubviewToBack(clouds)
        
        run(after: 1) {
            self.clouds.loadGif(name: "clouditzy")

        }

        
        //        clouds.backgroundColor = .green
        clouds.translatesAutoresizingMaskIntoConstraints = false
        clouds.heightAnchor.constraint(equalToConstant: 260).isActive=true
        clouds.topAnchor.constraint(equalTo: xama.topAnchor, constant: 180).isActive = true
        clouds.widthAnchor.constraint(equalToConstant: 1500).isActive = true
        cloudsBottomConstraint = clouds.leadingAnchor.constraint(equalTo: xama.leadingAnchor, constant: -20)
        cloudsBottomConstraint.isActive=true
        
    }
    
    func setupFarBackground(xama: UIView){
        xama.addSubview(farBackground)
        xama.sendSubviewToBack(farBackground)
        farBackground.clipsToBounds = false
        
        farBackground.translatesAutoresizingMaskIntoConstraints = false
        farBackground.heightAnchor.constraint(equalTo: xama.heightAnchor, multiplier: 0.5).isActive = true
        farBackground.widthAnchor.constraint(equalTo: xama.widthAnchor).isActive = true
        farBackground.bottomAnchor.constraint(equalTo: xama.bottomAnchor).isActive = true
        farBackground.trailingAnchor.constraint(equalTo: xama.trailingAnchor).isActive = true
        
    }
    
    func setupBackground(xama: UIView){
        xama.addSubview(background)
        xama.sendSubviewToBack(background)
        
        background.translatesAutoresizingMaskIntoConstraints = false
        background.heightAnchor.constraint(equalTo: xama.heightAnchor).isActive=true
        background.widthAnchor.constraint(equalTo: xama.widthAnchor).isActive=true
        background.bottomAnchor.constraint(equalTo: xama.bottomAnchor).isActive=true
        background.trailingAnchor.constraint(equalTo: xama.trailingAnchor).isActive=true
    }
    
    func setupDangerLabel(xama: UIView){
        xama.addSubview(dangerLabel)
        xama.bringSubviewToFront(dangerLabel)
        
        dangerLabel.text = "Current analysis: \(currentAnalysis)"
        dangerLabel.textAlignment = .center
        dangerLabel.font = dangerLabel.font.withSize(30)
        
        dangerLabel.translatesAutoresizingMaskIntoConstraints = false
        dangerLabelTopConstraint = dangerLabel.topAnchor.constraint(equalTo: xama.topAnchor, constant: -70)
        dangerLabelTopConstraint.isActive = true
        dangerLabel.leadingAnchor.constraint(equalTo: xama.leadingAnchor, constant: 20).isActive=true
        dangerLabel.trailingAnchor.constraint(equalTo: xama.trailingAnchor, constant: -20).isActive=true
        dangerLabel.heightAnchor.constraint(equalToConstant: 50).isActive = true
    }
    
    func run(after seconds: Int, completion: @escaping () -> Void) {
        let deadline = DispatchTime.now() + .seconds(seconds)
        DispatchQueue.main.asyncAfter(deadline: deadline) {
            completion()
        }
        
    }
    
    func animateDangerText2 (view: UIView, dangerLabelConstraint: NSLayoutConstraint) -> Void{
        
        UIView.animate(withDuration: 1, delay: 0.1, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
            
            dangerLabelConstraint.constant = 140
            view.layoutIfNeeded()
            
        }, completion: { (true) in
            self.run(after: 2, completion: {
                UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseInOut, animations: {
                    
                    dangerLabelConstraint.constant = -70
                    view.layoutIfNeeded()
                    
                    print ("caguei mole e a bosta escorreu")
                    
                })
            })
        })
        
    }
    
    func setupFoodList(xama: UIView){
        xama.addSubview(foodListView)
        foodListView.backgroundColor = .white
        foodListView.layer.cornerRadius = 12
        foodListView.layer.borderColor = UIColor.black.cgColor
        foodListView.layer.borderWidth = 4
        //        foodListView.layer.shouldRasterize = false
        //        foodListView.layer.masksToBounds = false
        //        foodListView.dropShadow(color: .red, offSet: CGSize(width: 1000, height: 1000))
        
        setupFoodListCOnstraint(xama: xama)
    }
    
    func setupFoodListCOnstraint(xama: UIView){
        foodListView.translatesAutoresizingMaskIntoConstraints = false
        foodListView.leadingAnchor.constraint(equalTo: xama.leadingAnchor, constant: 10).isActive = true
        foodListView.trailingAnchor.constraint(equalTo: xama.trailingAnchor, constant: -10).isActive = true
        foodListView.heightAnchor.constraint(equalToConstant: 170).isActive = true
        foodListBottomConstraint = foodListView.bottomAnchor.constraint(equalTo: xama.bottomAnchor, constant: 600)
        foodListBottomConstraint.isActive = true
        
    }
    
    func setupGuideText(xama: UIView){
        xama.addSubview(guideText)
        xama.bringSubviewToFront(guideText)
        
        guideText.text = guideTextText
        guideText.textAlignment = .center
        guideText.font = guideText.font.withSize(70)
        guideText.adjustsFontSizeToFitWidth = true
        
        //        guideText.backgroundColor = .blue
        
        guideText.translatesAutoresizingMaskIntoConstraints = false
        guideTextTopConstraint = guideText.topAnchor.constraint(equalTo: xama.topAnchor, constant: -70)
        guideTextTopConstraint.isActive = true
        guideText.leadingAnchor.constraint(equalTo: xama.leadingAnchor, constant: 20).isActive=true
        guideText.trailingAnchor.constraint(equalTo: xama.trailingAnchor, constant: -20).isActive=true
        guideText.heightAnchor.constraint(equalToConstant: 70).isActive=true
    }
    
    
    @objc func animateFoodList(xame: UIView) {
        
        if page > 0 {
            foodListBottomConstraint.constant = -80
        }
        
        var delay = TimeInterval()
        if page == 1 {
            delay=1
        }else{
            delay=0
        }
        
        guideTextTopConstraint.constant = 70
        UIView.animate(withDuration: 1, delay: delay, usingSpringWithDamping: 0.75, initialSpringVelocity: 1, options: .curveEaseOut, animations: {
            xame.layoutIfNeeded()
        }, completion: {_ in
            //            self.setupBackground()
        })
    }
    
    override public func receive(_ message: PlaygroundValue) {
        
        //        Uncomment the following to be able to receive messages from the Contents.swift playground page. You will need to define the type of your incoming object and then perform any actions with it.
        //
        //        guard case .data(let messageData) = message else { return }
        //        do { if let incomingObject = try NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(messageData) as? /*TypeOfYourObject*/ {
        //
        //                //do something with the incoming object from the playground page here
        //
        //            }
        //        } catch let error { fatalError("\(error) Unable to receive the message from the Playground page") }
        
    }
}
