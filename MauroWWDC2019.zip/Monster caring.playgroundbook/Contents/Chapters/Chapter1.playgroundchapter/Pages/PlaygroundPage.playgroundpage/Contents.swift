
/*:
 ![](sideRibbon.png)
 # ACCEPT IT!
 
  People usually think about their inner monsters as big evil creatures, while, actually, they are not that scary if you know how to treat them. Monsters grow accordingly to your interactions with them, and they can become more or less dangerous based on that.

 ### Analysis
 
 During your training, we will make use of technology to analyze the status of your monster before and after your work, but keep in mind that sometimes its not that easy to define wether you’re treating it correctly or not.

 ### Petting your monsters
 
 Your first lesson is about the basics of caregiving. Think about your monsters as if they were a pet, if you leave your dog alone and pretend that it’s not there, it will, probably, make a mess, right? So do your inner monsters!  It’s very important to keep in touch with your monsters and give them as much attention as possible, until you feel comfortable with them.
 
 ### Let's give it a try!
 **Give Lony, the loneliness monster, some love by petting it.**
 */
