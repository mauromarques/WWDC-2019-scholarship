
/*:
  ![](sideRibbon.png)
 # OVERCOME IT!
 
As you may have noticed, many of our monsters can be treated and dealt with by ourselves, but sometimes they are just too strong to overcome when you are alone.
 
 ### No one is ever alone
 
 However, here’s the trick, you are not alone! You have family, friends, coworkers, neighbors… people that know you and care for your. Even if you feel that no one is able to help, or that they are not willing to, remember that you don’t have to deal with your inner monsters by yourself.
 
 ### No need for shame
 
 Its very important to understand that it is ok to seek for help when you need it, and its ok to fall sometimes, we all do! We are still humans after all! Just keep in mind that maybe the words you need are just one call away, don’t be afraid to do it.
 
 # LETS GIVE IT A TRY!
 **Call your friends.**
 
 Sady: 12345 // Lony: 56789
 */
