
/*:
  ![](sideRibbon.png)
 # FEED IT!
 
As I said before, monsters grow accordingly to how you treat them,  but where do they take the energy needed to grow? Well, I’m glad you asked.

 ### Before getting into it
 
 First of all, some monsters will leave you after a certain amount of time, and that’s great! But others will stay with  you forever, so accepting their existence and learning the best approaches for a healthy coexistence are the key for overcoming this process.
 
 ### Vital forces
 
 Now, monsters get their vital forces from their owners feelings, so its always nice to be careful with how you treat them and try to keep calm while dealing with them. Cause in the end, we all want our monsters to have a balanced and healthy diet.
 
 ### Let's give it a try!
 **Feed Sady, the sadness monster, with healthy feelings.**
 */

